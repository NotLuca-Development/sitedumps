	function closebutton() {
		document.getElementById("container-sidebar").remove();
	  }
	  function openbutton() {
		document.getElementById("forkie").innerHTML += `<div id="container-sidebar">
		   <div class="sidebar">
			<div id="sidebar-menu">
			 <div class="sidebar-info-fixed">v1.5.7 <a id="switch-theme" ><i class="fa fa-lightbulb fa-margin"></i>Switch theme</a></div>
			 
			  <div class="sidebar-button-close-par">
			  <button class="sidebar-button-close" onclick="closebutton()">
			  <img src="https://dl.amogus.uk/static/svg/close.svg"/></button> 
			  </div>
			  <a title="Login" onclick='showLogin()'><i class='fa fa-user fa-margin'></i><span>Login</span></a>
			<a title="Search" onclick="$sel(':input', $toggle('search-panel')).focus()">
						<i class='fa fa-search fa-margin'></i><span>Search</span>
						</a>
						<a id="multiselection" title="Enable multi-selection" onclick='toggleSelection(); closebutton()'><i class='fa fa-check fa-margin'></i><span>Selection</span></a>	
                        <a id="sort" title="Change list order" onclick="changeSort()"><i class='fa fa-sort fa-margin' style="margin-right: 15px;"></i><span>Sort</span></a>
						<a id="toggleTs" title="Display timestamps" onclick="toggleTs(); closebutton();"><i class='fa fa-clock fa-margin'></i><span>Toggle timestamp</span></a>
			  <div class="sidebar-hr"></div>
			  <a href="mailto:support@amogus.uk">Support</a>
			  <a href="https://cdn.amogus.uk/">CDN</a>
		  </div></div></div>`;
		document.getElementById("sidebar-menu").style.display = "block";
		document.getElementById("container-sidebar").style.background =
		  "rgb(0 0 0 / 47%)";
	  }
	  