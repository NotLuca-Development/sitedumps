// <script> // this is here for the syntax highlighter
function wantArray(x) {
	return Array.isArray(x) ? x : [x]
}

function $create(tag, opts={}){
    let v = tag.split('.')
	tag = v.shift()
    let e = document.createElement(tag)
	if (v.length)
		e.setAttribute('class', v.join(' '))
	if (Array.isArray(opts) || opts instanceof Element)
		opts = { h:opts }
	if (v=opts.s)
	    e.style = v
    if (v=opts.t)
        e.textContent = v
    if (v=opts.h)
		if (typeof v==='string')
			e.innerHTML = v
		else
		    wantArray(v).forEach(x=> e.append(x))
	Object.assign(e, opts.a)
	if (v=opts.on)
		$on(e, v)
	if (v=opts.click)
		$on(e, { click:v })
	if (v=opts.app)
	    $sel(v).append(e)
    return e
}

function $msel(sel, root, opts={}) {
	if (typeof root==='function')
		opts=root, root=0
	if (!root)
		root = document
	sel = sel.replace(/:input\b/g, 'input,textarea,select,button')
	if (opts.single)
	    return root.querySelector(sel)
	let ret = [...root.querySelectorAll(sel)]
	if (typeof opts==='function')
		opts.f = opts
	if (opts.f)
		ret = ret.filter(opts.f)
	return ret
}

function $sel(sel, root){
    if (sel && sel instanceof Element)
        return sel
    return $msel(sel, root, { single:true })
}

function $on(root, evs, sel) {
	if (!root)
		root = document
	if (typeof root==='string')
	    root = $msel(root)
	for (let k in evs)
	    wantArray(root).forEach(r=> r.addEventListener(k, function(ev){
			if (sel && !(ev.delTarget = ev.target.closest(sel)))
				return
			if (false === evs[k].call(this,ev)) {
				ev.stopPropagation()
				ev.preventDefault()
			}
		}))
}

function $click(sel, cb, del) {
    if (typeof sel==='string') {
        let a = sel.split('/')
        if (a.length > 1)
            sel=a[0], del=a[1]
    }
    return $on(sel, { click:cb }, del)
}

function $toggle(id, state) {
	let r = typeof id==='string' ? document.getElementById(id) : id
	if (!r)
		return
	if (state===undefined)
	    state = r.style.display==='none'
	r.style.display = state ? '' : 'none'
	return r
}

function $xclass(el, cls, st) {
    let l = el.classList
    if (st===undefined ? l.contains(cls) : !st)
        return l.remove(cls), false
    l.add(cls)
    return true
}

function $post(url, data, opts) {
    return fetch(url, Object.assign({ method:'POST', cache:'no-cache', body:new URLSearchParams(data) }, opts))
        .then(r=> r.text())
}

function $button(lab, click) {
	let m = lab.split('@@')
	if (m.length > 1)
		lab = '<i class="fa fa-'+m[0]+'"></i> '+m[1]
	return $create('button', { h:lab, click })
}

function $form(form, field) {
    if (typeof form==='string')
        form = $sel(form)
    if (!form.elements)
        form = $sel('form', form)
	if (field)
		return form.elements.namedItem(field).value
	let ret = {}
	for (let e of form.elements)
		if (e.name) {
			let v = e.value
			if (field === false)
				v = v.trim()
			ret[e.name] = v
		}
	return ret
}

function $domReady(cb) {
	document.readyState !== 'loading' ? cb() : document.addEventListener('DOMContentLoaded', cb)
}

// options: cb(function), closable(false)
function dialog(content, options) {
	options = options||{}
	var cb = typeof options==='function' ? options : options.cb
	var active = document.activeElement
    var ret = $create('div.dialog-content', {
		h:content,
		on:{
			click(ev){ ev.stopImmediatePropagation() },
			keydown(ev){ ev.keyCode===27 && close2() }
		}
	})
	ret.close = ()=> {
        ret.closest('.dialog-overlay').remove()
		active.focus()
        cb && cb()
    }
	function close2(){
		if (options.closable !== false)
			ret.close()
	}

	$create('div.dialog-overlay', { h:ret, click:close2, app:'body' })
	setTimeout(()=>
		$sel(':input:not(:disabled)', ret).focus())
    return ret
}//dialog

// options: cb(function), buttons(jq|false)
function showMsg(content, options) {
	options = options||{}
	var cb = typeof options==='function' ? options : options.cb
	var bs = options.buttons
	if (~content.indexOf('<'))
		content = content.replace(/\n/g, '<br>')
    var ret = dialog($create('div', { s:'display:inline-block; text-Align:left' , h:content }), cb)
	//.css('text-align', 'center')
	if (bs!==false)
		$create('div.buttons', {
			app: ret,
			h: bs || $button("Ok", ()=> ret.close())
		})
	return ret
}//showMsg

function showError(msg, cb) {
	if (!msg)
		return
	let ret = showMsg("<h2>Error</h2>"+msg, cb)
	ret.classList.add('error')
    return ret
}

// from https://github.com/AndersLindman/SHA256
SHA256={K:[1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298],Uint8Array:function(r){return new("undefined"!=typeof Uint8Array?Uint8Array:Array)(r)},Int32Array:function(r){return new("undefined"!=typeof Int32Array?Int32Array:Array)(r)},setArray:function(r,n){if("undefined"!=typeof Uint8Array)r.set(n);else{for(var t=0;t<n.length;t++)r[t]=n[t];for(t=n.length;t<r.length;t++)r[t]=0}},digest:function(r){var n=1779033703,t=3144134277,e=1013904242,a=2773480762,i=1359893119,o=2600822924,A=528734635,f=1541459225,y=SHA256.K;if("string"==typeof r){var v=unescape(encodeURIComponent(r));r=SHA256.Uint8Array(v.length);for(var g=0;g<v.length;g++)r[g]=255&v.charCodeAt(g)}var u=r.length,h=64*Math.floor((u+72)/64),l=h/4,s=8*u,d=SHA256.Uint8Array(h);SHA256.setArray(d,r),d[u]=128,d[h-4]=s>>>24,d[h-3]=s>>>16&255,d[h-2]=s>>>8&255,d[h-1]=255&s;var S=SHA256.Int32Array(l),H=0;for(g=0;g<S.length;g++){var c=d[H]<<24;c|=d[H+1]<<16,c|=d[H+2]<<8,c|=d[H+3],S[g]=c,H+=4}for(var U=SHA256.Int32Array(64),p=0;p<l;p+=16){for(g=0;g<16;g++)U[g]=S[p+g];for(g=16;g<64;g++){var I=U[g-15],w=I>>>7|I<<25;w^=I>>>18|I<<14,w^=I>>>3;var C=(I=U[g-2])>>>17|I<<15;C^=I>>>19|I<<13,C^=I>>>10,U[g]=U[g-16]+w+U[g-7]+C&4294967295}for(var K=n,b=t,m=e,M=a,R=i,j=o,k=A,q=f,g=0;g<64;g++){C=R>>>6|R<<26,C^=R>>>11|R<<21;var x=q+(C^=R>>>25|R<<7)+(R&j^~R&k)+y[g]+U[g]&4294967295,w=K>>>2|K<<30;w^=K>>>13|K<<19;var z=K&b^K&m^b&m,q=k,k=j,j=R,R=M+x&4294967295,M=m,m=b,b=K,K=x+((w^=K>>>22|K<<10)+z&4294967295)&4294967295}n=n+K&4294967295,t=t+b&4294967295,e=e+m&4294967295,a=a+M&4294967295,i=i+R&4294967295,o=o+j&4294967295,A=A+k&4294967295,f=f+q&4294967295}var B=SHA256.Uint8Array(32);for(g=0;g<4;g++)B[g]=n>>>8*(3-g)&255,B[g+4]=t>>>8*(3-g)&255,B[g+8]=e>>>8*(3-g)&255,B[g+12]=a>>>8*(3-g)&255,B[g+16]=i>>>8*(3-g)&255,B[g+20]=o>>>8*(3-g)&255,B[g+24]=A>>>8*(3-g)&255,B[g+28]=f>>>8*(3-g)&255;return B},hash:function(r){var n=SHA256.digest(r),t="";for(i=0;i<n.length;i++){var e="0"+n[i].toString(16);t+=2<e.length?e.substring(1):e}return t}};


function sha256(s) { return SHA256.hash(s) }

function showLogin(options) {
	if (!HFS.sid) // the session was just deleted
		return location.reload()
	let warning = `<div style='border-bottom:1px solid #888; margin-bottom:1em; padding-bottom:1em;'>
		The current account (${HFS.user}) has no access to this resource.
		<br>Please enter different credentials.
	</div>`
	let d = dialog($create('form', {
		s:'line-height:1.9em',
		// the following works because HFS.user is always a string
		h: (HFS.user && warning)+`
			Username
			<br><input name=usr />
			<br>Password
			<br><input name=pwd type=password />
			<br><br><button type=submit>Login</button>
		`,
		on:{
			submit(){
				var v = $form(d, false)
				var data = {
					user: v.usr,
					passwordSHA256: sha256(sha256(v.pwd)+HFS.sid)  // hash must be lowercase. Double-hashing is causing case sensitiv
				}
				$post("?mode=login", data).then(res=>{
					if (res !== 'ok')
						return showError(res)
					d.close()
					showLoading()
					location.reload()
				}, ajaxError);
				return false
			}
		}
	}), options)
} // showLogin

function showLoading(show){
	if (showLoading.last)
		showLoading.last.close()
	if (show===false)
		return
	let ret = showLoading.last = showMsg('<i class="fa fa-refresh" style="animation:spin 6s linear infinite;position: absolute;top: calc(50% - .5em);left: calc(50% - 0.5em); font-size: 12em; font-size:min(50vw, 50vh); color: #fff;" />',{ buttons:false })
	ret.style.background = 'none'
	return ret
}


function ajax(method, data, cb) {
    if (!data)
        data = {};
    data.token = HFS.sid; // avoid CSRF attacks
    showLoading()
    // calling this section 'under' the current folder will affect permissions commands like 
    return $post("?mode=section&id=ajax."+method, data).then(res=>{
        if (cb)
            showLoading(false)
        ;(cb||getStdAjaxCB())(res)
    }, ajaxError);
}//ajax

function changePwd() {
	if (!HFS.canChangePwd)
		return showError("Sorry, you lack permissions for this action")
	ask(`Warning: the password will be sent unencrypted to the server. For better security change the password from HFS window.
		<hr><i class="fa fa-key"></i> Enter new password`,
		'password',
		s=>
			s && ajax('changepwd', {'new':s}, getStdAjaxCB(function(){
				showLoading(false)
				showMsg("Password changed")
			}))
	)
}//changePwd

function selectionChanged() { $sel('#selected-counter').textContent = getSelectedItems().length }

function getItemName(el) {
    if (!el)
        return false
    var a = el.closest('a') || $sel('.item-link a', el.closest('.item'))
    // take the url, and ignore any #anchor part
    var s = a.href || a.value
    s = s.split('#')[0]
    // remove protocol and hostname
    var i = s.indexOf('://');
    if (i > 0)
        s = s.slice(s.indexOf('/',i+3));
    // current folder is specified. Remove it.
    if (s.indexOf(HFS.folder) == 0)
        s = s.slice(HFS.folder.length);
    // folders have a trailing slash that's not truly part of the name
    if (s.slice(-1) == '/')
        s = s.slice(0,-1);
    // it is encoded
    s = (decodeURIComponent || unescape)(s);
    return s;
} // getItemName

function submit(data, url) {
    var f = $create('form', { app:'body', a:{method:'post', action:url||undefined }, s:'display:none' })
    for (var k in data)
		wantArray(data[k]).forEach(v2=>
			$create('input', { app:f, a:{type:'hidden', name:k, value:v2 } }))
    f.submit()
}//submit

RegExp.escape = function(text) {
    if (!arguments.callee.sRE) {
        var specials = '/.*+?|()[]{}\\'.split('');
        arguments.callee.sRE = new RegExp('(\\' + specials.join('|\\') + ')', 'g');
    }
    return text.replace(arguments.callee.sRE, '\\$1');
}//escape


/*  cb: function(value, dialog)
	options: type:string(text,textarea,number), value:any, keypress:function
*/
function ask(msg, options, cb) {
    // 2 parameters means "options" is missing
    if (arguments.length == 2) {
        cb = options;
        options = {};
    }
	if (typeof options==='string')
		options = { type:options }
    msg += '<br />';
    var v = options.type
    var buttons = `<div class=buttons>
		<button>Ok</button>
		<button class="cancel">Cancel</button>
	</div>`
	if (v == 'textarea')
		msg += '<textarea name="txt">'+options.value+'</textarea>';
	else if (v)
		msg += '<input name="txt" type="'+v+'" value="'+(options.value||'')+'" />';
    msg += buttons
	var ret = dialog( $create('form.ask', { h:msg, on:{
		submit(ev){
		    if (ev.submitter.classList.contains('cancel')
			|| false !== cb(options.type ? $sel(':input', ret).value.trim() : ev.target, ev.target.closest('form'))) {
                ret.close()
                return false
            }
		}
	} }) )

    let i = $sel(':input', ret)
	if (i) {
		i.focus() 
		if (i.select) i.select() 
	}

	return ret
}

function getStdAjaxCB(what2do) {
    return function(res){
        res = res.trim()
        if (res === "ok")
			return (typeof what2do==='function') ? what2do() : location.reload()
		showLoading(false)
		showError(res)
    }
}

function getSelectedItems() {
    return $msel('#files .selector:checked')
}

function getSelectedItemsName() {
    return getSelectedItems().map(getItemName)
}

function deleteFiles(files) {
	ask("Are you sure?", ()=>{
		submit({ action:'delete', selection:files })
		showLoading()
	})
}

function moveFiles(files) {
	ask("Enter the destination folder", 'text', function(dst) {
		return ajax('move', { dst, files: files.join(':') }, function(res) {
			var a = res.split(';')
			a.pop()
			if (!a.length)
				return showMsg($.trim(res))
			var failed = 0;
			var ok = 0;
			var msg = '';
			a.forEach(s=> {
				s = s.trim()
				if (!s.length) {
					ok++
					return
				}
				failed++;
				msg += s+'\n'
			})
			if (failed)
				msg = "We met the following problems:\n"+msg
			msg = (ok ? ok+' files were moved.\n' : "No file was moved.\n")+msg
			if (ok)
				showMsg(msg, reload)
			else
				showError(msg)
		})
	})
}//moveFiles

function reload() { location = '.' }

function selectionMask() {
    ask("Please enter the file mask to select", {type:'text', value:'*'}, s=>{
        if (!s) return;
        var re = s.match('^/([^/]+)/([a-zA-Z]*)');
        if (re)
            re = new RegExp(re[1], re[2]);
        else {
            var n = s.match(/^(\\*)/)[0].length;
            s = s.substring(n);
            var invert = !!(n % 2);
            s = RegExp.escape(s).replace(/[?]/g,".");;
            if (s.match(/\\\*/)) {
                s = s.replace(/\\\*/g,".*");
                s = "^ *"+s+" *$"; // in this case var the user decide exactly how it is placed in the string
            }
            re = new RegExp(s, "i");
        }
        $msel( "#files .selector", e=>
			(invert ^ re.test(getItemName(e))) && (e.checked=true))
        selectionChanged()
    });
}//selectionMask

function showAccount() {
	dialog(`<div style="line-height:3em">
			<h1>Account panel</h1>
			<span>User: ${HFS.user}</span>
			<br><button onclick="changePwd()"><i class="fa fa-key"></i> Change password</button>
			<br><button onclick="logout()"><i class="fa fa-logout"></i> Logout</button>
        </div>`)
} // showAccount

function logout(){
	showLoading()
	$post('?mode=logout').then(()=> location.reload(), ajaxError);
}

function setCookie(name,value,days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        var expires = "; expires="+date.toGMTString();
    }
    else var expires = "";
    document.cookie = name+"="+value+expires+"; path=/";
} // setCookie

function delCookie(name) { setCookie(name,'', -1) }

function getCookie(name) {
	var a = document.cookie.match(new RegExp('(?:^| )' + name + '=([^;]+)'))
	return a && a[1]
} // getCookie

// quando in modalità selezione, viene mostrato una checkbox per ogni item, e viene anche mostrato un pannello per all/none/invert
var multiSelection = false
function toggleSelection() {
    $toggle('selection-panel')
	if (multiSelection = !multiSelection) {
		let base = $create('input.selector', { a:{type:'checkbox'} })
		$msel('.item-selectable a', e=> // having the checkbox inside the A element will put it on the same line of A even with long A, otherwise A will start on a new line.
			e.append(base.cloneNode()) )
	}
	else
		$msel('#files .selector', x=> x.remove())
}//toggleSelection

function upload(){
	$create('input', {
		a:{ type:'file', name:'file', multiple:true },
		on: { change(ev){
			var files = ev.target.files
			if (!files.length) return
			$toggle('upload-panel')
			uploadQ.add(done=>
				sendFiles(files, done))
		} }
  	}).click()
} //upload

uploadQ = newQ(n=>
    $sel('#upload-q').textContent = Math.max(0, n-1) ) // we don't consider the one we are working

function newQ(onChange){
    var a = []
	var ret = {
		add(job) {
			a.push(job)
			change()
			if (a.length!==1) return
			job(function consume(){
				a.shift() // trash it
				if (a.length)
					a[0](consume) // next
				change()
			})
		}
	}

    function change(){ onChange && onChange(a.length) }

	return ret
}//newQ

function changeSort(){
	let u = urlParams // shortcut
    dialog([
        $create('h3', { t:'Sort by' }),
        $create('div.buttons', objToArr(sortOptions, (label,code)=>
            $button( (u.sort===code ? 'sort-alt-'+(u.rev?'down':'up')+'@@' : '')+label, ()=>{
				u.rev = (u.sort===code && !u.rev) ? 1 : undefined
				u.sort = code||undefined
				location.search = encodeURL(urlParams)
			})
		))
	])
}//changeSort

function objToArr(o, cb){
    var ret = []
	for (var k in o) {
	    var v = o[k]
		ret.push(cb(v,k))
	}
	return ret
}

function sendFiles(files, done) {
    var formData = new FormData()
    for (var i = 0; i < files.length; i++)
        formData.append('file', files[i])

	var xhr = new XMLHttpRequest();
	xhr.open('POST', '');
	xhr.send(formData);
	xhr.onload = data=> {
		try {
			data = JSON.parse(data)
			data.forEach(r=> {
				let e = $sel('#upload-panel'+(r.err ? 'ko' : 'ok'))
				e.textContent = +e.textContent +1
				$toggle(e.parentNode, true) // only for 'ko'
				e = r.err ? $create('span', { a:{title:r.err}, h:'<i class="fa fa-ban"></i> '+ r.name })
					: $create('a', {
						a: { href:r.url, title:`Size: '+r.size+'&#013;Speed: '+r.speed+'B/s` },
						h: '<i class="fa fa-'+(r.err ? 'ban' : 'check-circled')+'"></i> '+r.name
					})
				$sel('#upload-results').appendChild(e)
			})
		}
		catch(e){
			console.error(e)
			showError('Invalid server reply')
		}
		done()
	}
	xhr.onerror = done

	var e = $sel('#upload-progress')
	var prog = $sel('progress', e)
	prog.value = 0
	$toggle(e)
	var last = 0
	var now = 0
	xhr.onprogress = ev=>
		prog.value = (now = ev.loaded) / ev.total
	var h = setInterval(()=>{
		$sel('#progress-text').textContent = smartSize(now)+'B @ '+smartSize(now-last)+'/s'
		last = now
	},1000)
	xhr.onload = ev=> {
		$toggle(e)
		clearInterval(h)
	}
}

function smartSize(n, options) {
    options = options||{}
	var orders = ['','K','M','G','T','P']
	var order = options.order||1024
	var max = options.maxOrder||orders.length-1
	var i = 0
	while (n >= order && i<max) {
		n /= order
		++i
	}
	if (options.decimals===undefined)
		options.decimals = n<5 ? 1 : 0
	return round(n, options.decimals)
		+orders[i]
}

function round(v, digits) {
	return !digits ? Math.round(v) : Math.round(v*Math.pow(10,digits)) / Math.pow(10,digits)
}

function log(){
	console.log.apply(console,arguments)
	return arguments[arguments.length-1]
}

function toggleTs(){
    let k = 'hideTs'
    let now = $xclass($sel('#files'), k)
    localStorage.setItem('ts', Number(!now));
}

function decodeURL(urlData) {
	var ret = {}
    for (let x of urlData.split('&')) {
        if (!x) continue
        x = x.split("=").map(decodeURIComponent)
		ret[x[0]] = x.length===1 || x[1]
    }
	return ret
}//decodeURL

function encodeURL(obj) {
    var ret = []
	for (var k in obj) {
	    var v = obj[k]
		if (v===undefined) continue
		k = encodeURIComponent(k)
	    if (v !== true)
	        k += '='+encodeURIComponent(v)
		ret.push(k)
	}
	return ret.join('&')
}//encodeURL

function ajaxError(x){
	showError(x.status || 'communication error')
}

urlParams = decodeURL(location.search.substring(1))
sortOptions = {
	n: "Name",
	e: "Extension",
	s: "Size",
	t: "Timestamp",
	d: "Hits",
	'': 'Default'
}

function $icon(name, title, opts) {
    if (typeof opts==='function')
        opts = { click:opts }
	return $create('i.fa.fa-'+name, Object.assign({ title },opts))
}

function mustSelect() {
    return getSelectedItems().length
        || showError(`You need to select some files first`)
        && 0
}

$domReady(()=>{
	if (!$sel('#menu-panel')) // this is an error page
		return
    $msel('.trash-me', x=> x.remove()) // this was hiding things for those w/o js capabilities
    if (Number(localStorage['ts']))
        toggleTs()

    $click('/.item-menu', ev=>{
        var it = ev.target.closest('.item')
        var acc = it.matches('.can-access')
        var name = getItemName(ev.target)
        dialog([
            $create('h3', { t:name }),
            $sel('.item-ts', it).cloneNode(true),
            $create('div.buttons', [
                it.closest('.can-delete')
				&& $button('trash@@Delete', ()=> deleteFiles([name])),
                it.closest('.can-rename')
				&& $button('edit@@Rename', renameItem),
                it.closest('.can-comment')
				&& $button('quote-left@@Comment', setComment),
                it.closest('.can-move')
				&& $button('truck@@Move', ()=> moveFiles([name]) )
            ])
        ]).classList.add('item-menu-dialog')

        function setComment() {
            let e = $sel('.comment-text',it)
            let value = e && e.textContent || '';
            ask(this.innerHTML, { type: 'textarea', value }, s=>{
                if (s !== value)
                    ajax('comment', { text: s, files: name })
            })
        }//setComment

        function renameItem() {
            ask(this.innerHTML+ ' '+name, { type: 'text', value: name }, to=>
                ajax("rename", { from: name, to }))
        }
    })

	$click('/.selector', ev=>{
		setTimeout(()=>{ // we are keeping the checkbox inside an A tag for layout reasons, and firefox72 is triggering the link when the checkbox is clicked. So we reprogram the behaviour.
			ev.target.checked ^= 1
			selectionChanged()
		})
		return false
	})

	$click('#select-invert', ev=>{
        $msel('#files .selector', x=> x.checked=!x.checked)
        selectionChanged()
    })

    $click('#select-mask', selectionMask)
    $click('#move-selection',()=>
        mustSelect() && moveFiles(getSelectedItemsName()) )
	$toggle('move-selection', $sel('.can-delete'))
    $click('#delete-selection', ()=>
        mustSelect() && deleteFiles(getSelectedItemsName()) )
    $toggle('delete-selection', $sel('.can-delete'))
    $click('#archive', ()=>
        mustSelect() && ask("Downloading many files as archive can be a lengthy operation, and the result is a TAR file. Continue?", ()=>
            submit({ selection: getSelectedItemsName() }, "/~lib.js?mode=archive&recursive") ))

    $msel('#files .cannot-access .item-link img', x=>
		x.insertAdjacentElement('afterend', $icon('lock', "No access") ))
	$msel('#files.can-delete .item:not(.cannot-access), #files .item.can-archive', x=>
		$xclass(x,'item-selectable',1))
    if (! $sel('.item-selectable'))
        $toggle('#multiselection', false)

    $msel('.additional-panel.closeable', x=>
		x.prepend( $icon('times-circle close', 'close', ev=>{
            let e = ev.target.closest('.closeable')
            $toggle(e, false)
            e.dispatchEvent(new CustomEvent('closed'))
        })) )

    $on('#upload-panel', { closed(){
        $sel('#upload-ok').textContent = 0
		$sel('#upload-ko').textContent = 0
        $sel('#upload-results').textContent = ''
    } })

	//$sel('#sort span').textContent = sortOptions[urlParams.sort]||'Sort'

    selectionChanged()
})//$domReady
